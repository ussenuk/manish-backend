from setuptools import setup

setup(
    name='integration-portal',
    version='0.1',
    packages=['portalsdk'],
    url='www.4cgroup.co.za',
    license='MIT',
    author='4C Group',
    author_email='',
    description=''
)
